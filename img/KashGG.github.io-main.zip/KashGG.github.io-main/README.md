"Private Project is Private website that I can share my projects with other people..
